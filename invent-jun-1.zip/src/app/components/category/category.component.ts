import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSelectionList, MatSelectionListChange } from '@angular/material/list';
import { ConfiguratorService } from '../../services/configurator.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {

  private categories: any;
  public categoryList: any;
  public searchValue: any;
  @ViewChild(MatSelectionList) selectedCategories: MatSelectionList;

  constructor(private configuratorService: ConfiguratorService) { }

  ngOnInit(): void {
    this.configuratorService.getCategories().subscribe((res) => {
      this.categories = res;
      this.categoryList = res;
    })

    this.selectedCategories.selectionChange.subscribe((category: MatSelectionListChange) => {
      this.selectedCategories.deselectAll();
    });
  }

  public filterCategory() {
    this.categoryList = this.categories.filter((category: { name: (string | undefined)[]; }) => {
      return category.name.indexOf(this.searchValue) >= 0;
    });
  }

}
